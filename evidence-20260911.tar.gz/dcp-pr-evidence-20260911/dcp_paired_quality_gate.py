#!/usr/bin/env python3
"""Conservative per-repeat paired quality bound; repeats are not independent."""
import argparse
import hashlib
import json
from pathlib import Path

PROTOCOL = dict(version="gsm8k-train5-natural-mtp-v1", primary_repeat=0,
                margin=0.01, temperature=0, max_new_tokens=4096,
                concurrency=4, repeats=2, golden=False, sampling_seed=42,
                dataset_sha256="3730d312f6e3440559ace48831e51066acaca737f6eabec99bccb9e4b3c39d14",
                train_sha256="17f347dc51477c50d4efb83959dbb7c56297aba886e5544ee2aaed3024813465")
PROTOCOL_HASH = hashlib.sha256(json.dumps(PROTOCOL,sort_keys=True).encode()).hexdigest()


def formal_contract_valid(contract):
    ids = contract.get("ids", [])
    return (len(ids) == 1319 and len(set(ids)) == 1319 and set(ids) == set(range(1319))
            and contract.get("few_shot_split") == "train" and contract.get("few_shot_ids") == list(range(5))
            and contract.get("protocol") == PROTOCOL and contract.get("protocol_sha256") == PROTOCOL_HASH
            and all(contract.get(k) == PROTOCOL[k] for k in ("temperature","max_new_tokens","concurrency","repeats","sampling_seed","dataset_sha256","train_sha256"))
            and contract.get("golden") is False
            and isinstance(contract.get("prompts_sha256"),str) and len(contract["prompts_sha256"])==64)


def paired_bound(gains, losses, n, margin=0.01):
    from scipy.stats import beta
    if not (n > 0 and 0 <= gains <= n and 0 <= losses <= n and gains + losses <= n):
        raise ValueError("Invalid paired counts")
    # Two one-sided 97.5% intervals: Bonferroni coverage at least 95%.
    gain_lower = float(beta.ppf(0.025, gains, n-gains+1)) if gains else 0.0
    loss_upper = float(beta.ppf(0.975, losses+1, n-losses)) if losses < n else 1.0
    lower = gain_lower - loss_upper
    return dict(n=n, gains=gains, losses=losses, delta=(gains-losses)/n,
                lower_95_conservative=lower, margin=margin,
                noninferiority_bound_passed=lower > -margin)


def compare(first, second):
    def read(folder):
        rows = [json.loads(line) for line in (folder / "responses.jsonl").read_text().splitlines()]
        keyed = {(r["id"], r["repeat"]):r for r in rows}
        if len(keyed) != len(rows):
            raise ValueError("Duplicate question/repeat")
        return json.loads((folder / "contract.json").read_text()), keyed
    ca, a = read(first)
    cb, b = read(second)
    if ca != cb or a.keys() != b.keys():
        raise ValueError("Mismatched contracts or responses")
    expected = {(i, r) for i in ca["ids"] for r in range(ca["repeats"])}
    if a.keys() != expected:
        raise ValueError("Incomplete paired responses")
    result = []
    for repeat in range(ca["repeats"]):
        keys = [(i, repeat) for i in ca["ids"]]
        gains = sum(not a[k]["correct"] and b[k]["correct"] for k in keys)
        losses = sum(a[k]["correct"] and not b[k]["correct"] for k in keys)
        row = paired_bound(gains, losses, len(keys))
        row.update(repeat=repeat,
                   d1_correct=sum(a[k]["correct"] for k in keys),
                   d4_correct=sum(b[k]["correct"] for k in keys),
                   d1_truncated=sum(a[k]["truncated"] for k in keys),
                   d4_truncated=sum(b[k]["truncated"] for k in keys),
                   request_errors=sum(a[k]["request_error"] or b[k]["request_error"] for k in keys))
        result.append(row)
    return dict(repeats=result, primary_repeat=0, unique_questions=len(ca["ids"]),
                formal_contract_valid=formal_contract_valid(ca), protocol_sha256=PROTOCOL_HASH,
                formal_primary_gate_passed=formal_contract_valid(ca)
                and result[0]["noninferiority_bound_passed"] and not any(r["request_errors"] for r in result),
                note="Primary repeat0 predeclared; other repeats diagnostic, not pooled. Quality bound alone does not qualify the PR.")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("first", type=Path)
    p.add_argument("second", type=Path)
    args = p.parse_args()
    print(json.dumps(compare(args.first, args.second), indent=2))
