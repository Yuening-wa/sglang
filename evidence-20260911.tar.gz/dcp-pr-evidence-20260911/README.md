# SM120 packed DSA DCP reviewer evidence — local handoff

This bundle is not uploaded and does not represent an opened or approved PR.
Full GSM8K and C4/C8 3600s performance were measured on SHA 75af57096.
The latest-main candidate is 3e930fbbe (base 822e73ccd); all three feature
patches are range-diff equivalent. Its 57 CPU tests and 5 GPU kernel tests pass,
as do the final-page production-write checks. Consult versions-and-status.json
for the actual latest-main boundary/model screen status; do not infer missing
tests passed or relabel old full measurements as tests of the new SHA.

## Scope and scoring

GLM-5.2 NVFP4, eight SM120 GPUs, TP8/PP1/DCP4, FP8 packed KV, native chain
MTP5/topk1. Other models, PP/EP, HiCache/HiSparse/offload and DCP2/8 end-to-end
are not claims of this evidence. Accuracy is NATURAL acceptance, not gold.
First five GSM8K train examples; all 1319 test questions; two repeats; C4,
temperature 0, seed 42, maximum 4096 new tokens, default model chat template.
Primary repeat 0 was declared in advance; repeat 1 is diagnostic, not pooled.
Truncated answers count as incorrect even if their final number matches.
The paired score passes the declared 1pp non-inferiority margin, not a universal
model-equivalence claim or an upstream-mandated threshold.

Raw answer text, output token IDs and relevant acceptance/finish metadata are
preserved. Server request IDs, timestamps, weight labels and other metadata
are omitted by allowlist; these files are sanitized derivatives, not byte-exact
copies of original response logs. Contracts and prompts remain byte-exact.
The prompt file is public GSM8K content encoded as input IDs. Source dataset:
https://github.com/openai/grade-school-math (MIT); its license is included in
GSM8K-LICENSE.txt. The model's outputs and license remain
subject to the corresponding model terms.

## Replay the published score

Install scipy, then run from this directory:

```bash
python dcp_paired_quality_gate.py accuracy-d1 accuracy-d4
```

Full evaluation additionally needs transformers and a running matching model
server. Use server-launch.md for the portable launch instructions. Example:

```bash
python run_dcp_natural_qualification.py --url http://127.0.0.1:32620 \
  --model-path /path/to/GLM-5.2-NVFP4 --dataset /path/to/test.jsonl \
  --train-dataset /path/to/train.jsonl --num-questions 1319 --output fresh-d4
```

The exported evaluator differs only by requiring --model-path instead of a
private machine default. This is export configuration, not a protocol change.
The protocol and prompt hashes remain in each contract. Re-run separately for D1.
Unset all SGLANG_SIMULATE_ACC_* settings for accuracy. The evaluator retains
its historical preliminary-diagnostic label; paired-score.json contains the
separately computed complete paired gate, not that label alone.

## Performance interpretation

See performance.md/csv/json. These are ABSOLUTE recipe results, not matched
DCP-on/off speedup measurements. Historical D1 has a different SHA and graph
policy and is intentionally not exported as a controlled comparison.
C counts root traces, not simultaneous server requests. Graph limits are 8/16
at C4/C8, with admission cap 32. No cache offloading is enabled.

- X = 1 / P90(E2E seconds / output tokens), NOT 1/P90 TPOT.
- Y/GPU = completed input+output tokens / active-request envelope seconds / 8,
  NOT simply divided by the requested 3600-second window.
- TTFT/TPOT use counted profiling requests; warmup requests are excluded.
- KV peak is sampled pressure, not allocated memory bytes.
- KV and token-weighted server prefix-hit counters retain the historical
  warmup + profiling + end-of-run collection window. Prefix is trace/server.
- Gold uses upstream acceptance simulation: SGLANG_SIMULATE_ACC_LEN=3.61,
  SGLANG_SIMULATE_ACC_METHOD=match-expected,
  SGLANG_SIMULATE_ACC_TOKEN_MODE=real-draft-token. No gold code is added by
  this feature. Gold performance is NOT natural-MTP deployment performance.

Model/tokenizer revision and AgentX workload/harness revision still require
export. Without those, exact external performance reproduction is incomplete;
internal report links are deliberately not required or included here.

## Integrity and privacy

SHA256SUMS hashes every payload file except itself and SAFETY-SCAN.json.
The safety scan rejects known private path/host markers, IPv4 addresses other
than localhost, private report domains, credential-key assignments, and key
blocks. Metadata is allowlisted. This is an automated bounded check, not proof
that arbitrary generated text can never contain sensitive-looking strings.
No environment dump, full server info, hostname, credential, or internal URL is
included. The adjacent tar.gz archive contains exactly the manifested bundle.
