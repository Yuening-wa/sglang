#!/usr/bin/env python3
"""Small paired natural-MTP diagnostic, NOT a full model-quality qualification.

Five disjoint few-shot examples; 64 fixed test IDs; two repetitions; C4.
Numeric extraction matches the local SGLang mixed-prefix GSM8K evaluator.
Raw tokens, responses, truncations and acceptance metadata are retained.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import random
import re
import time
import urllib.request


def answer(text):
    values = re.findall(r"-?\d+\.?\d*", text.replace(",", ""))
    try:
        return ast.literal_eval(values[-1]) if values else None
    except (ValueError, SyntaxError):
        return None


def post(url, route, data):
    req = urllib.request.Request(url + route, data=json.dumps(data).encode(), headers={"Content-Type":"application/json"})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=1800) as response:
        payload = response.read().decode()
        return payload if route == "/flush_cache" else json.loads(payload)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--dataset", type=Path, required=True)
    p.add_argument("--train-dataset", type=Path)
    p.add_argument("--num-questions", type=int, default=64)
    p.add_argument("--model-path", required=True,
                   help="Required local tokenizer/model directory for external reproduction")
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    from transformers import AutoTokenizer
    model = args.model_path
    tokenizer = AutoTokenizer.from_pretrained(model, trust_remote_code=True)
    data = [json.loads(line) for line in args.dataset.read_text().splitlines()]
    assert len(data) == 1319
    examples = data[:5]
    population = range(5, len(data))
    if args.train_dataset:
        train = [json.loads(line) for line in args.train_dataset.read_text().splitlines()]
        assert len(train) == 7473
        examples = train[:5]
        assert not ({r["question"].strip() for r in examples} & {r["question"].strip() for r in data})
        population = range(len(data))
    ids = sorted(random.Random(42).sample(population, args.num_questions))
    prefix = "".join(f"Question: {r['question']}\nAnswer: {r['answer']}\n\n" for r in examples)
    prompts = []
    for idx in ids:
        text = prefix + f"Question: {data[idx]['question']}\nAnswer:"
        tokens = tokenizer.apply_chat_template([{"role":"user", "content":text}], tokenize=True, add_generation_prompt=True, return_dict=False)
        if not isinstance(tokens, list) or not all(isinstance(token, int) for token in tokens):
            raise TypeError("Expected flat token-ID list from the model chat template")
        prompts.append(dict(id=idx, input_ids=tokens, expected=answer(data[idx]["answer"])))
    contract = dict(dataset_sha256=hashlib.sha256(args.dataset.read_bytes()).hexdigest(), source_url="https://raw.githubusercontent.com/openai/grade-school-math/master/grade_school_math/data/test.jsonl", ids=ids, few_shot_ids=list(range(5)), repeats=2, concurrency=4, temperature=0, max_new_tokens=4096, sampling_seed=42, template="model default apply_chat_template(add_generation_prompt=True)", scorer="last numeric value, local SGLang mixed-prefix GSM8K convention", golden=False, qualification="preliminary diagnostic; no formal non-inferiority claim", prompts_sha256=hashlib.sha256(json.dumps(prompts,sort_keys=True).encode()).hexdigest())
    contract.update(num_questions=len(ids), few_shot_split="train" if args.train_dataset else "test-excluded", train_sha256=hashlib.sha256(args.train_dataset.read_bytes()).hexdigest() if args.train_dataset else None)
    if args.train_dataset:
        from dcp_paired_quality_gate import PROTOCOL, PROTOCOL_HASH
        contract.update(protocol=PROTOCOL, protocol_sha256=PROTOCOL_HASH)
    (args.output / "contract.json").write_text(json.dumps(contract, indent=2) + "\n")
    (args.output / "prompts.json").write_text(json.dumps(prompts) + "\n")
    rows = []
    start = time.time()
    with (args.output / "responses.jsonl").open("x") as out:
        for repeat in range(2):
            post(args.url, "/flush_cache", {})
            for offset in range(0, len(prompts), 4):
                group = prompts[offset:offset+4]
                result = post(args.url, "/generate", {"input_ids":[r["input_ids"] for r in group], "sampling_params":{"temperature":0,"max_new_tokens":4096,"sampling_seed":42}, "return_logprob":False})
                assert isinstance(result,list) and len(result) == len(group), result
                for expected, response in zip(group, result):
                    predicted = answer(response.get("text", ""))
                    meta = response.get("meta_info", {})
                    finish = meta.get("finish_reason", {})
                    finish_type = finish.get("type") if isinstance(finish,dict) else finish
                    request_error = bool(response.get("error") or meta.get("error") or finish_type not in ("stop", "length"))
                    row = dict(id=expected["id"], repeat=repeat, expected=expected["expected"], predicted=predicted, correct=not request_error and finish_type == "stop" and predicted == expected["expected"], raw_answer_matches=predicted == expected["expected"], request_error=request_error, truncated=finish_type == "length", response=response)
                    rows.append(row)
                    out.write(json.dumps(row, ensure_ascii=False) + "\n")
                    out.flush()
                progress = dict(completed=len(rows), total=2*len(ids), correct=sum(r["correct"] for r in rows), truncated=sum(r["truncated"] for r in rows), elapsed_seconds=time.time()-start)
                (args.output / "progress.json").write_text(json.dumps(progress, indent=2) + "\n")
                print(progress, flush=True)
                if any(r["request_error"] for r in rows):
                    (args.output / "error.json").write_text(json.dumps({"error":"Invalid/aborted response; inspect preserved raw responses", "progress":progress}, indent=2) + "\n")
                    raise RuntimeError("Aborted, error or unknown finish reason; stopping qualification")
    summary = dict(contract=contract, completed=len(rows), accuracy=sum(r["correct"] for r in rows)/len(rows), truncated=sum(r["truncated"] for r in rows), invalid=sum(r["predicted"] is None for r in rows), repeats=[dict(repeat=i,correct=sum(r["correct"] for r in rows if r["repeat"]==i), total=len(ids)) for i in range(2)], elapsed_seconds=time.time()-start, model_accuracy_qualified=False)
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(summary, flush=True)


if __name__ == "__main__":
    main()
